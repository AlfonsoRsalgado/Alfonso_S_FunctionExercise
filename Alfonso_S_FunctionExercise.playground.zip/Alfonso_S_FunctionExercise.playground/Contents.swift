func printMathResult( a: Int, b:Int) -> Int {
   return a + b
}
print("Result: \(printMathResult(a: 3, b: 5))")
// Prints "Result: 8"




